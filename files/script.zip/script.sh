#!/bin/bash

echo "hi" >> hi
